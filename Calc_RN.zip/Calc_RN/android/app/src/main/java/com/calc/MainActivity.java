package com.calc;

import org.devio.rn.splashscreen.SplashScreen;
import android.os.Bundle;

import com.facebook.react.ReactActivity;

public class MainActivity extends ReactActivity {

  @Override
  protected void onCreate(Bundle saveInstanceState){
    SplashScreen.show(this);
    super.onCreate(saveInstanceState);

  }
  @Override
  protected String getMainComponentName() {
    return "calculator";
  }
}
