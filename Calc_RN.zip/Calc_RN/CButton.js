import React, {Component} from 'react';
import {TouchableOpacity, Text} from 'react-native';

class CButton extends Component {
  render() {
    return (
      <TouchableOpacity onPress={this.props.fun} style={this.props.styles}>
        <Text style={this.props.stylesBtx}>{this.props.name}</Text>
      </TouchableOpacity>
    );
  }
}
export default CButton;
